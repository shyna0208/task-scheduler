-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 07, 2020 at 04:45 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_task`
--

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE IF NOT EXISTS `task` (
  `name` text NOT NULL,
  `due` date NOT NULL,
  `priority` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`name`, `due`, `priority`, `id`, `task`) VALUES
('sorabh', '2020-04-14', 'High', 1, 'Create Login Page'),
('Ritika', '2020-04-22', 'Low', 11, 'Create a Website'),
('Cheenam Bajaj', '2020-04-10', 'Low', 3, 'create login page'),
('Ritika', '2020-04-10', 'High', 5, 'create login page'),
('Surbhi', '2020-04-25', 'Medium', 7, 'create login page');
